/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.meteocal.exception;

/**
 *This exception is thrown when a date of a event is illegal
 * @author Andrea
 */
public class IllegalEventDateException extends Exception {
    
}
